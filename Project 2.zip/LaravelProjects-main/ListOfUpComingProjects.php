<?php
// // 1-Creating Auto-Suggest Search with Laravel and jQuery Typeahead: (Done)
// // 2-Importing From Excel:(Done)
// // 3-Exporting to Excel:(Done)
// ! 4 Generate PDF with Laravel: (Done)
// ! 5 laravel CRUD with Validations And Notify (Done)
// ! 6 Laravel Localization
// ! 7 laravel CSV Export (Done)
// ! 8 laravel Login using phone number or email (Done)
// ! 9 Laravel Take and upload Screen shot
// ! 10 Laravel Crop, Resize Image and upload
// ! 11 Implement Google reCaptcha
// ! 12 Get Location Information With IP Address In Laravel
